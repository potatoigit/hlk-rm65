package asus

// requires a usb stick
// nvram set script_usbmount=some command
