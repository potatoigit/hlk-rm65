// +build !windows

package windows

// Placeholder to make Go happy.
