//+build !windows

package config

const DefaultControl = "/var/run/nextdns.sock"
