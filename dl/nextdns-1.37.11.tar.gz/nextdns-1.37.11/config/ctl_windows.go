package config

const DefaultControl = "nextdns-cli"
