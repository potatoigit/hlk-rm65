---
name: CLI Client Feature request
about: Suggest an idea for the CLI client (see below for general feature suggestions).
title: ''
labels: "✨ feature-request"
assignees: ''

---


