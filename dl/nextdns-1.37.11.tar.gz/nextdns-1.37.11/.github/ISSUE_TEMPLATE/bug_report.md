---
name: CLI Client Bug report
about: 'Report bug in the CLI client (see below for bugs about the NextDNS service itself).'
title: ''
labels: "\U0001F41E bug"
assignees: ''

---
**Context**
 - CLI Version: 
 - Platform:

&lt;Describe the bug>
